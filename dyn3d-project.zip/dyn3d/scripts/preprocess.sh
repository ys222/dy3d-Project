#!/usr/bin/env bash
# preprocess.sh <video.mp4> <output_dir>
#
# Full preprocessing pipeline: video -> frames -> subject masks -> monocular
# depth -> optical flow -> long-term tracks -> initial camera poses.
#
# This script assumes you've separately installed: ffmpeg, COLMAP, and the
# Python packages for SAM2 / Depth Anything V2 / RAFT / CoTracker3 listed in
# requirements.txt's comments.

set -euo pipefail

VIDEO="$1"
OUT="$2"

mkdir -p "$OUT"/{frames,masks,depth,flow}

echo "[1/6] Extracting frames..."
ffmpeg -i "$VIDEO" -vf "fps=15" "$OUT/frames/%04d.png"

echo "[2/6] Running SAM2 subject segmentation..."
python -m src.preprocessing.run_sam2 --frames "$OUT/frames" --out "$OUT/masks"

echo "[3/6] Running monocular depth (Depth Anything V2)..."
python -m src.preprocessing.run_depth --frames "$OUT/frames" --out "$OUT/depth"

echo "[4/6] Running optical flow (RAFT) between adjacent frames..."
python -m src.preprocessing.run_flow --frames "$OUT/frames" --out "$OUT/flow"

echo "[5/6] Running long-term point tracking (CoTracker3)..."
python -m src.preprocessing.run_tracking --frames "$OUT/frames" --masks "$OUT/masks" --out "$OUT/tracks.npz"

echo "[6/6] Estimating camera poses (masked COLMAP)..."
python -m src.geometry.camera --frames "$OUT/frames" --masks "$OUT/masks" --out "$OUT/cameras.json"

echo "Preprocessing complete: $OUT"
