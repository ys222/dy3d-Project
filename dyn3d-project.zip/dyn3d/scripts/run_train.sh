#!/usr/bin/env bash
# run_train.sh <data_dir> [config]
set -euo pipefail

DATA_DIR="$1"
CONFIG="${2:-configs/default.yaml}"

cd "$(dirname "$0")/.."
python src/train.py --config "$CONFIG" --data "$DATA_DIR"
