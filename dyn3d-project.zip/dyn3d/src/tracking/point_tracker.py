"""
point_tracker.py

Wraps CoTracker3 for long-term point tracking across the whole clip. This is
the module that most differentiates a robust dynamic reconstruction pipeline
from a naive per-frame-pair approach: adjacent-frame optical flow alone lets
small errors accumulate/drift over time and gives no signal once a point is
briefly occluded and reappears. Long-term tracks provide direct, sparse but
reliable correspondences across arbitrarily distant frames, used as a hard
supervision signal for the deformation field (see losses.py: track_consistency_loss).
"""

from pathlib import Path

import numpy as np
import torch


class LongTermPointTracker:
    def __init__(self, device: str = "cuda"):
        self.device = device
        # self.model = torch.hub.load("facebookresearch/co-tracker", "cotracker3_offline").to(device)
        raise NotImplementedError(
            "Load CoTracker3 (offline mode, since we have the full clip up front). "
            "See https://github.com/facebookresearch/co-tracker"
        )

    @torch.no_grad()
    def track_grid(self, video: torch.Tensor, grid_size: int = 30, mask: torch.Tensor | None = None):
        """
        video: (1, T, 3, H, W) float32 in [0, 255]
        mask: optional (H, W) — restrict query points to subject region (recommended,
              since the deformation field only needs supervision where it deforms;
              background gaussians are static and don't need tracking).

        Returns:
            coords: (N, T, 2) pixel coordinates of N tracked points across T frames
            visibility: (N, T) bool, whether each point is visible (not occluded) in each frame
        """
        raise NotImplementedError

    def save(self, coords: np.ndarray, visibility: np.ndarray, out_path: Path):
        np.savez(out_path, coords=coords, visibility=visibility)


def track_reprojection_loss(rendered_coords: torch.Tensor, gt_coords: torch.Tensor, visibility: torch.Tensor):
    """
    Given the canonical-space 3D points that back a set of tracked pixels, and their
    projected 2D positions under the estimated deformation + camera at each frame,
    penalize disagreement with the ground-truth tracked 2D coordinates.

    rendered_coords, gt_coords: (N, T, 2)
    visibility: (N, T) bool — only supervise where the point is actually visible.
    """
    diff = (rendered_coords - gt_coords).norm(dim=-1)  # (N, T)
    diff = diff[visibility]
    return diff.mean() if diff.numel() > 0 else torch.tensor(0.0)
