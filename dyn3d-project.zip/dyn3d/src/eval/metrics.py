"""
metrics.py

Evaluation against held-out views (e.g. DyCheck's extra validation cameras, or
your own held-out frames). This is the metric that actually matters for this
project -- see README.md section 8 for why held-out-view PSNR/SSIM/LPIPS is
used instead of training-view reconstruction error, which can look great while
the underlying 3D/deformation is badly wrong.
"""

import argparse

import lpips
import numpy as np
import torch
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim


class Evaluator:
    def __init__(self, device: str = "cuda"):
        self.device = device
        self.lpips_fn = lpips.LPIPS(net="alex").to(device)

    def compute(self, rendered: torch.Tensor, target: torch.Tensor) -> dict:
        """rendered, target: (3, H, W) float32 in [0, 1]"""
        r_np = rendered.permute(1, 2, 0).cpu().numpy()
        t_np = target.permute(1, 2, 0).cpu().numpy()

        return {
            "psnr": float(psnr(t_np, r_np, data_range=1.0)),
            "ssim": float(ssim(t_np, r_np, data_range=1.0, channel_axis=2)),
            "lpips": float(self.lpips_fn(
                rendered.unsqueeze(0) * 2 - 1, target.unsqueeze(0) * 2 - 1
            ).item()),
        }

    def flicker_score(self, frames: list[torch.Tensor], static_mask: list[torch.Tensor]) -> float:
        """
        Temporal-consistency proxy: pixel variance over time in regions expected to
        be static (background, or subject regions with near-zero optical flow).
        Lower is better. Not a substitute for held-out-view metrics, but useful for
        diagnosing flicker artifacts that per-frame PSNR won't catch.
        """
        stacked = torch.stack(frames, dim=0)          # (T, 3, H, W)
        mask_stacked = torch.stack(static_mask, dim=0)  # (T, 1, H, W)
        variance = stacked.var(dim=0)                   # (3, H, W)
        masked_variance = variance * mask_stacked.mean(dim=0)
        return masked_variance.mean().item()


def run_eval(run_dir: str, data_root: str):
    raise NotImplementedError(
        "Load checkpoint from run_dir, render held-out views from data_root, "
        "call Evaluator.compute() per frame, and report mean +/- std across the clip."
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--data", required=True)
    args = parser.parse_args()
    run_eval(args.run, args.data)
