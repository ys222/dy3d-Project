"""
losses.py

All training losses. The core tension this project fights: photometric loss
alone (standard for static 3DGS/NeRF) is not enough for dynamic scenes — it's
satisfied by many wrong deformations that happen to render correctly from the
*single* training camera trajectory (this is exactly the failure mode DyCheck's
benchmark was built to expose). The tracking and ARAP losses exist specifically
to constrain the deformation field toward physically plausible solutions rather
than merely photometrically-plausible-from-one-viewpoint ones.
"""

import torch
import torch.nn.functional as F
from pytorch_msssim import ssim as ssim_fn  # pip install pytorch-msssim


def photometric_loss(rendered: torch.Tensor, target: torch.Tensor, l1_weight: float, ssim_weight: float):
    l1 = F.l1_loss(rendered, target)
    ssim_val = ssim_fn(rendered.unsqueeze(0), target.unsqueeze(0), data_range=1.0)
    return l1_weight * l1 + ssim_weight * (1.0 - ssim_val)


def depth_prior_loss(rendered_depth: torch.Tensor, prior_depth: torch.Tensor, mask: torch.Tensor | None = None):
    """
    Scale/shift-invariant loss against the monocular depth prior (which has
    unknown, possibly per-frame-inconsistent scale). Aligns rendered depth to
    the prior via least squares before comparing, rather than comparing raw
    values directly.
    """
    r = rendered_depth.flatten()
    p = prior_depth.flatten()
    if mask is not None:
        m = mask.flatten() > 0
        r, p = r[m], p[m]
    if r.numel() < 10:
        return torch.tensor(0.0, device=rendered_depth.device)

    A = torch.stack([p, torch.ones_like(p)], dim=1)
    solution = torch.linalg.lstsq(A, r.unsqueeze(1)).solution
    scale, shift = solution[0, 0], solution[1, 0]
    aligned_prior = scale * p + shift
    return F.l1_loss(r, aligned_prior)


def flow_consistency_loss(rendered_flow: torch.Tensor, estimated_flow: torch.Tensor, mask: torch.Tensor | None = None):
    """Compare 2D motion implied by the deformation field (via finite differences of
    projected canonical points between adjacent frames) against RAFT's estimated flow."""
    diff = (rendered_flow - estimated_flow)
    if mask is not None:
        diff = diff * mask
        denom = mask.sum().clamp_min(1.0)
        return diff.abs().sum() / denom
    return diff.abs().mean()


def arap_loss(canonical_xyz: torch.Tensor, deformed_xyz: torch.Tensor, neighbor_idx: torch.Tensor):
    """
    As-Rigid-As-Possible regularization: pairwise distances between each Gaussian
    and its k-nearest canonical-space neighbors should be roughly preserved after
    deformation. This is what stops the deformation field from producing physically
    implausible stretching/tearing that still happens to satisfy photometric loss
    from the single observed viewpoint.

    canonical_xyz, deformed_xyz: (N, 3)
    neighbor_idx: (N, k) precomputed k-NN indices in canonical space
    """
    n, k = neighbor_idx.shape
    canon_diff = canonical_xyz.unsqueeze(1) - canonical_xyz[neighbor_idx]          # (N, k, 3)
    deformed_diff = deformed_xyz.unsqueeze(1) - deformed_xyz[neighbor_idx]          # (N, k, 3)
    canon_dist = canon_diff.norm(dim=-1)
    deformed_dist = deformed_diff.norm(dim=-1)
    return F.l1_loss(deformed_dist, canon_dist)


def opacity_regularizer(opacity_logit: torch.Tensor):
    """Encourage opacities toward 0 or 1 (discourage translucent 'ghost' gaussians)."""
    opacity = torch.sigmoid(opacity_logit)
    return (opacity * (1 - opacity)).mean()


def scale_regularizer(log_scale: torch.Tensor, max_scale: float = 0.1):
    """Penalize gaussians that grow too large (common failure: a few huge gaussians
    cheaply explain flat regions but destroy fine detail and novel-view quality)."""
    scale = torch.exp(log_scale)
    return F.relu(scale - max_scale).mean()


def total_loss(components: dict, weights: dict) -> tuple[torch.Tensor, dict]:
    """Combine loss terms per configs/default.yaml weights. Returns total + a dict
    of unweighted individual terms for logging."""
    total = torch.tensor(0.0, device=next(iter(components.values())).device)
    logged = {}
    for name, value in components.items():
        weight_key = f"{name}_weight"
        w = weights.get(weight_key, 0.0)
        total = total + w * value
        logged[name] = value.item()
    return total, logged
