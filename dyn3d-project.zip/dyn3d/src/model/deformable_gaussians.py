"""
deformable_gaussians.py

The core scene representation:
- A set of 3D Gaussians in a CANONICAL space (position, rotation, scale, opacity,
  spherical-harmonic color coefficients) — split into a static background subset
  and a deformable subject subset.
- A deformation MLP that maps (canonical position, time) -> (delta position,
  delta rotation, delta scale), conditioned on a small per-frame latent code so
  the network can represent motion that isn't a pure function of position+time
  alone (e.g. distinguishing "arm going up" vs "arm going down" at similar poses).

At render time: canonical subject gaussians are deformed per-frame by the MLP,
concatenated with the (undeformed) background gaussians, and both are rasterized
together with gsplat.
"""

import torch
import torch.nn as nn


class PositionalEncoding(nn.Module):
    def __init__(self, num_freqs: int, include_input: bool = True):
        super().__init__()
        self.num_freqs = num_freqs
        self.include_input = include_input
        self.freq_bands = 2.0 ** torch.arange(num_freqs)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = [x] if self.include_input else []
        for freq in self.freq_bands.to(x.device):
            out.append(torch.sin(x * freq))
            out.append(torch.cos(x * freq))
        return torch.cat(out, dim=-1)


class DeformationField(nn.Module):
    """MLP: (encoded xyz, encoded t, per-frame latent) -> (delta_xyz, delta_rot_quat, delta_scale)"""

    def __init__(self, hidden_dim: int, num_layers: int, latent_dim: int,
                 xyz_freqs: int, time_freqs: int, num_frames: int):
        super().__init__()
        self.xyz_pe = PositionalEncoding(xyz_freqs)
        self.time_pe = PositionalEncoding(time_freqs)
        self.frame_latents = nn.Embedding(num_frames, latent_dim)

        xyz_dim = 3 * (2 * xyz_freqs + 1)
        time_dim = 1 * (2 * time_freqs + 1)
        in_dim = xyz_dim + time_dim + latent_dim

        layers = []
        dim = in_dim
        for _ in range(num_layers):
            layers += [nn.Linear(dim, hidden_dim), nn.ReLU(inplace=True)]
            dim = hidden_dim
        self.backbone = nn.Sequential(*layers)

        self.out_xyz = nn.Linear(hidden_dim, 3)
        self.out_rot = nn.Linear(hidden_dim, 4)    # quaternion delta
        self.out_scale = nn.Linear(hidden_dim, 3)

        # Zero-init output heads so the field starts as identity (no deformation),
        # which stabilizes early training a lot.
        for layer in (self.out_xyz, self.out_rot, self.out_scale):
            nn.init.zeros_(layer.weight)
            nn.init.zeros_(layer.bias)

    def forward(self, xyz_canonical: torch.Tensor, t: torch.Tensor, frame_idx: int):
        """
        xyz_canonical: (N, 3)
        t: (N, 1) normalized timestamp in [0, 1]
        frame_idx: int, used to look up the per-frame latent code
        """
        n = xyz_canonical.shape[0]
        latent = self.frame_latents(torch.full((n,), frame_idx, device=xyz_canonical.device, dtype=torch.long))
        feats = torch.cat([self.xyz_pe(xyz_canonical), self.time_pe(t), latent], dim=-1)
        h = self.backbone(feats)
        delta_xyz = self.out_xyz(h)
        delta_rot = self.out_rot(h)      # added to identity quaternion at use site
        delta_scale = self.out_scale(h)
        return delta_xyz, delta_rot, delta_scale


class CanonicalGaussians(nn.Module):
    """
    Holds the learnable canonical Gaussian parameters, split into static background
    (never deformed — saves compute and gives a strong inductive bias that the
    background shouldn't move) and subject (deformed per-frame by DeformationField).
    """

    def __init__(self, bg_points: torch.Tensor, subject_points: torch.Tensor, sh_degree: int = 3):
        super().__init__()
        n_sh = (sh_degree + 1) ** 2

        def make_params(points):
            n = points.shape[0]
            return nn.ParameterDict({
                "xyz": nn.Parameter(points.clone()),
                "log_scale": nn.Parameter(torch.full((n, 3), -3.0)),
                "rot_quat": nn.Parameter(torch.cat([torch.ones(n, 1), torch.zeros(n, 3)], dim=-1)),
                "opacity_logit": nn.Parameter(torch.full((n, 1), 0.0)),
                "sh_coeffs": nn.Parameter(torch.zeros(n, n_sh, 3)),
            })

        self.bg = make_params(bg_points)
        self.subject = make_params(subject_points)

    def get_deformed_subject(self, deformation_field: DeformationField, t: float, frame_idx: int):
        xyz = self.subject["xyz"]
        t_tensor = torch.full((xyz.shape[0], 1), t, device=xyz.device)
        delta_xyz, delta_rot, delta_scale = deformation_field(xyz, t_tensor, frame_idx)

        deformed_xyz = xyz + delta_xyz
        deformed_rot = self.subject["rot_quat"] + delta_rot  # renormalize before use
        deformed_rot = deformed_rot / deformed_rot.norm(dim=-1, keepdim=True).clamp_min(1e-8)
        deformed_log_scale = self.subject["log_scale"] + delta_scale

        return {
            "xyz": deformed_xyz,
            "rot_quat": deformed_rot,
            "log_scale": deformed_log_scale,
            "opacity_logit": self.subject["opacity_logit"],
            "sh_coeffs": self.subject["sh_coeffs"],
        }

    def get_full_scene(self, deformation_field: DeformationField, t: float, frame_idx: int):
        """Concatenate deformed subject with static background for rendering."""
        deformed = self.get_deformed_subject(deformation_field, t, frame_idx)
        combined = {}
        for key in deformed:
            combined[key] = torch.cat([self.bg[key], deformed[key]], dim=0)
        return combined
