"""
train.py

Main training loop. Ties together:
  DynamicClipDataset -> CanonicalGaussians + DeformationField -> gsplat rasterizer
  -> losses.py -> backprop.

This is written as an explicit, readable loop (not a Trainer abstraction) since
at this project's scope you WILL want to step through it with a debugger while
diagnosing why the deformation field is doing something wrong -- that's most of
the actual work in weeks 3-6 of the roadmap in README.md.
"""

import argparse
from pathlib import Path

import torch
import yaml
from tqdm import tqdm

from data.dataset import DynamicClipDataset
from model.deformable_gaussians import CanonicalGaussians, DeformationField
from model.losses import (
    arap_loss, depth_prior_loss, flow_consistency_loss,
    opacity_regularizer, photometric_loss, scale_regularizer, total_loss,
)
from tracking.point_tracker import track_reprojection_loss

# from gsplat import rasterization  # actual differentiable rasterizer call


def build_knn(xyz: torch.Tensor, k: int = 8) -> torch.Tensor:
    """Precompute k-nearest-neighbor indices in canonical space for ARAP loss."""
    dists = torch.cdist(xyz, xyz)
    _, idx = dists.topk(k + 1, largest=False)  # includes self at index 0
    return idx[:, 1:]


def render_frame(gaussians_dict: dict, cam_extrinsic: torch.Tensor, cam_intrinsic: torch.Tensor, image_size):
    """
    Wraps the gsplat rasterization call. Left as an integration point since the
    exact call signature depends on the installed gsplat version -- see
    https://docs.gsplat.studio for the current API.

    Should return: rendered_rgb (3,H,W), rendered_depth (1,H,W), rendered_alpha (1,H,W)
    """
    raise NotImplementedError("Wire up gsplat.rasterization() here with gaussians_dict fields.")


def main(config_path: str, data_root: str):
    with open(config_path) as f:
        cfg = yaml.safe_load(f)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    dataset = DynamicClipDataset(
        root=data_root,
        image_scale=cfg["data"]["image_scale"],
        num_frames=cfg["data"]["num_frames"],
    )

    # --- Initialization: unproject first-frame depth to seed canonical gaussians ---
    # bg_points, subject_points = init_from_depth(dataset)  # TODO, see geometry/depth_flow.py
    bg_points = torch.randn(10000, 3)       # placeholder
    subject_points = torch.randn(20000, 3)  # placeholder

    gaussians = CanonicalGaussians(
        bg_points, subject_points, sh_degree=cfg["gaussians"]["sh_degree"]
    ).to(device)

    deformation_field = DeformationField(
        hidden_dim=cfg["deformation"]["hidden_dim"],
        num_layers=cfg["deformation"]["num_layers"],
        latent_dim=cfg["deformation"]["latent_dim"],
        xyz_freqs=cfg["deformation"]["positional_encoding_freqs"],
        time_freqs=cfg["deformation"]["time_encoding_freqs"],
        num_frames=len(dataset),
    ).to(device)

    knn_idx = build_knn(gaussians.subject["xyz"].detach())

    optimizer = torch.optim.Adam([
        {"params": gaussians.bg.parameters(), "lr": cfg["train"]["lr_gaussians_xyz"]},
        {"params": gaussians.subject.parameters(), "lr": cfg["train"]["lr_gaussians_xyz"]},
        {"params": deformation_field.parameters(), "lr": cfg["train"]["lr_deformation_mlp"]},
    ])

    weights = cfg["losses"]

    pbar = tqdm(range(cfg["train"]["iterations"]))
    for step in pbar:
        frame_idx = step % len(dataset)
        sample = dataset[frame_idx]

        scene = gaussians.get_full_scene(deformation_field, sample.timestamp, frame_idx)
        rendered_rgb, rendered_depth, rendered_alpha = render_frame(
            scene, sample.cam_extrinsic.to(device), sample.cam_intrinsic.to(device),
            image_size=sample.image.shape[-2:],
        )

        deformed_subject = gaussians.get_deformed_subject(deformation_field, sample.timestamp, frame_idx)

        components = {
            "photometric": photometric_loss(
                rendered_rgb, sample.image.to(device),
                weights["photometric_l1_weight"], weights["photometric_ssim_weight"],
            ),
            "depth_prior": depth_prior_loss(rendered_depth, sample.depth_prior.to(device)),
            "arap": arap_loss(gaussians.subject["xyz"], deformed_subject["xyz"], knn_idx),
            "opacity_reg": opacity_regularizer(gaussians.subject["opacity_logit"]),
            "scale_reg": scale_regularizer(gaussians.subject["log_scale"]),
        }
        # flow_consistency and track_consistency omitted from this skeleton loop for
        # brevity -- wire in using flow_consistency_loss() / track_reprojection_loss()
        # once render_frame() also returns projected canonical points per frame.

        loss, logged = total_loss(components, weights)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # TODO: densification/pruning of gaussians per configs densify_* schedule
        # (standard 3DGS adaptive density control, applied to `gaussians.subject`)

        if step % cfg["train"]["log_every"] == 0:
            pbar.set_postfix(**{k: f"{v:.4f}" for k, v in logged.items()})

        if step % cfg["train"]["eval_every"] == 0 and step > 0:
            pass  # TODO: call eval/metrics.py on held-out views

        if step % cfg["train"]["checkpoint_every"] == 0 and step > 0:
            out_dir = Path("outputs") / cfg["experiment_name"]
            out_dir.mkdir(parents=True, exist_ok=True)
            torch.save({
                "gaussians": gaussians.state_dict(),
                "deformation_field": deformation_field.state_dict(),
                "step": step,
            }, out_dir / f"ckpt_{step:06d}.pt")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--data", required=True)
    args = parser.parse_args()
    main(args.config, args.data)
