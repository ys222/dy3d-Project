"""
dataset.py

Loads a preprocessed clip directory and serves per-frame training samples:
image, subject mask, monocular depth prior, optical flow to neighbor frames,
long-term point tracks, and camera pose.

Expected directory layout (produced by scripts/preprocess.sh):

data/my_clip/
├── frames/           0000.png, 0001.png, ...
├── masks/            0000.png, ... (subject mask, 0/255)
├── depth/             0000.npy, ... (relative monocular depth)
├── flow/              0000_0001.npy, ... (frame i -> i+1 optical flow)
├── tracks.npz         long-term point tracks across all frames (from CoTracker)
└── cameras.json       per-frame extrinsics + shared intrinsics
"""

import json
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset


@dataclass
class FrameSample:
    frame_idx: int
    image: torch.Tensor          # (3, H, W) float32 [0,1]
    mask: torch.Tensor           # (1, H, W) float32 {0,1}
    depth_prior: torch.Tensor    # (1, H, W) float32, relative depth
    flow_fwd: torch.Tensor | None  # (2, H, W) float32, flow to frame_idx+1
    cam_extrinsic: torch.Tensor  # (4, 4) world-to-camera
    cam_intrinsic: torch.Tensor  # (3, 3)
    timestamp: float             # normalized in [0, 1]


class DynamicClipDataset(Dataset):
    def __init__(self, root: str, image_scale: float = 1.0, num_frames: int | None = None):
        self.root = Path(root)
        self.image_scale = image_scale

        with open(self.root / "cameras.json") as f:
            self.cameras = json.load(f)

        self.frame_paths = sorted((self.root / "frames").glob("*.png"))
        if num_frames is not None:
            self.frame_paths = self.frame_paths[:num_frames]
        self.n_frames = len(self.frame_paths)

        tracks_path = self.root / "tracks.npz"
        self.tracks = np.load(tracks_path) if tracks_path.exists() else None
        # tracks["coords"]: (num_points, n_frames, 2)
        # tracks["visibility"]: (num_points, n_frames) bool

        self.intrinsic = torch.tensor(self.cameras["intrinsic"], dtype=torch.float32)

    def __len__(self):
        return self.n_frames

    def _load_image(self, idx: int) -> torch.Tensor:
        img = cv2.imread(str(self.frame_paths[idx]))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        if self.image_scale != 1.0:
            h, w = img.shape[:2]
            img = cv2.resize(img, (int(w * self.image_scale), int(h * self.image_scale)))
        return torch.from_numpy(img).permute(2, 0, 1).float() / 255.0

    def _load_mask(self, idx: int) -> torch.Tensor:
        mask_path = self.root / "masks" / self.frame_paths[idx].name
        mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
        if self.image_scale != 1.0:
            h, w = mask.shape[:2]
            mask = cv2.resize(mask, (int(w * self.image_scale), int(h * self.image_scale)))
        return torch.from_numpy(mask).float().unsqueeze(0) / 255.0

    def _load_depth(self, idx: int) -> torch.Tensor:
        depth_path = self.root / "depth" / f"{self.frame_paths[idx].stem}.npy"
        depth = np.load(depth_path)
        return torch.from_numpy(depth).float().unsqueeze(0)

    def _load_flow(self, idx: int) -> torch.Tensor | None:
        if idx >= self.n_frames - 1:
            return None
        flow_path = self.root / "flow" / f"{idx:04d}_{idx + 1:04d}.npy"
        if not flow_path.exists():
            return None
        flow = np.load(flow_path)
        return torch.from_numpy(flow).float().permute(2, 0, 1)

    def _get_camera(self, idx: int):
        cam = self.cameras["frames"][idx]
        extrinsic = torch.tensor(cam["extrinsic"], dtype=torch.float32)  # 4x4
        return extrinsic, self.intrinsic

    def __getitem__(self, idx: int) -> FrameSample:
        extrinsic, intrinsic = self._get_camera(idx)
        return FrameSample(
            frame_idx=idx,
            image=self._load_image(idx),
            mask=self._load_mask(idx),
            depth_prior=self._load_depth(idx),
            flow_fwd=self._load_flow(idx),
            cam_extrinsic=extrinsic,
            cam_intrinsic=intrinsic,
            timestamp=idx / max(self.n_frames - 1, 1),
        )

    def get_tracks_for_frames(self, frame_indices: list[int]):
        """Return (coords, visibility) for the requested frames, for track-consistency loss."""
        if self.tracks is None:
            return None, None
        coords = self.tracks["coords"][:, frame_indices, :]         # (N, k, 2)
        visibility = self.tracks["visibility"][:, frame_indices]    # (N, k)
        return torch.from_numpy(coords).float(), torch.from_numpy(visibility).bool()
