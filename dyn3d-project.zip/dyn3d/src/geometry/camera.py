"""
camera.py

Estimates per-frame camera pose from a video containing a moving subject.
Standard SfM (COLMAP) assumes a static scene, so it will fail or produce
garbage if you feed it frames with a moving person in them. The fix used
here: mask out the subject (via SAM2 masks produced in preprocessing) before
handing frames to COLMAP, so only the static background is used for pose
estimation. This is the standard workaround for "dynamic SfM" at this scope
(see: full dynamic SLAM systems like DROID-SLAM as a fancier alternative).
"""

import json
import shutil
import subprocess
from pathlib import Path

import cv2
import numpy as np


def mask_out_subject(frame_path: Path, mask_path: Path, out_path: Path):
    """Write a copy of the frame with subject pixels blacked out, for COLMAP input."""
    frame = cv2.imread(str(frame_path))
    mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
    frame[mask > 0] = 0
    cv2.imwrite(str(out_path), frame)


def run_colmap_masked(frames_dir: Path, masks_dir: Path, workspace: Path) -> dict:
    """
    Runs COLMAP's automatic reconstruction pipeline on background-masked frames
    and parses the resulting camera poses into a simple JSON structure.

    Requires the `colmap` binary on PATH. See https://colmap.github.io/install.html
    """
    masked_dir = workspace / "masked_frames"
    masked_dir.mkdir(parents=True, exist_ok=True)
    for frame_path in sorted(frames_dir.glob("*.png")):
        mask_path = masks_dir / frame_path.name
        mask_out_subject(frame_path, mask_path, masked_dir / frame_path.name)

    db_path = workspace / "database.db"
    sparse_dir = workspace / "sparse"
    sparse_dir.mkdir(exist_ok=True)

    subprocess.run(
        ["colmap", "automatic_reconstructor",
         "--workspace_path", str(workspace),
         "--image_path", str(masked_dir),
         "--camera_model", "PINHOLE",
         "--single_camera", "1",
         "--dense", "0"],
        check=True,
    )

    return parse_colmap_output(sparse_dir / "0")


def parse_colmap_output(model_dir: Path) -> dict:
    """
    Parses COLMAP's images.txt / cameras.txt into the cameras.json schema
    consumed by DynamicClipDataset. Left as a TODO — use pycolmap
    (pip install pycolmap) for a much cleaner read than manual text parsing:

        import pycolmap
        recon = pycolmap.Reconstruction(str(model_dir))
        for image_id, image in recon.images.items():
            extrinsic = image.cam_from_world.matrix()  # 3x4
            ...
    """
    raise NotImplementedError("Parse COLMAP sparse model into {'intrinsic':..., 'frames':[...]}")


def refine_poses_with_gradient(initial_cameras: dict, renderer, images) -> dict:
    """
    Optional: after initial COLMAP pose estimation, treat camera extrinsics as
    learnable parameters and refine them jointly with the Gaussian scene during
    early training (small LR, see configs/default.yaml `lr_camera_refine`).
    This compensates for the fact that masked-SfM poses can be noisy, especially
    when the background has few trackable features (e.g. indoor scenes with
    large textureless walls).
    """
    raise NotImplementedError("Wire into train.py's optimizer parameter groups.")
