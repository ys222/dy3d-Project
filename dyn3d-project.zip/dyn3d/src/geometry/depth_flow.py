"""
depth_flow.py

Thin wrappers around pretrained monocular depth (Depth Anything V2) and
optical flow (RAFT) models, used only at preprocessing time to build the
cached signals that dataset.py loads. Keeping these frozen/off-the-shelf
is deliberate: the point of this project is the *dynamic reconstruction*,
not re-deriving depth/flow from scratch.
"""

from pathlib import Path

import numpy as np
import torch


class MonocularDepthEstimator:
    """
    Wraps Depth Anything V2. Produces *relative* depth (up to unknown scale
    and shift per frame) — the training loss must be scale/shift-invariant
    (see losses.py: depth_prior_loss) since these are not metric depths and
    are not guaranteed consistent in scale across frames.
    """

    def __init__(self, encoder: str = "vitl", device: str = "cuda"):
        self.device = device
        # from depth_anything_v2.dpt import DepthAnythingV2
        # self.model = DepthAnythingV2(encoder=encoder, ...).to(device).eval()
        # self.model.load_state_dict(torch.load(f"checkpoints/depth_anything_v2_{encoder}.pth"))
        raise NotImplementedError(
            "Install Depth Anything V2 and wire up the checkpoint path here. "
            "See https://github.com/DepthAnything/Depth-Anything-V2"
        )

    @torch.no_grad()
    def predict(self, image_bgr: np.ndarray) -> np.ndarray:
        """image_bgr: HxWx3 uint8 -> returns HxW float32 relative depth (higher = closer or
        farther depending on model convention — normalize consistently in preprocessing)."""
        raise NotImplementedError


class OpticalFlowEstimator:
    """Wraps RAFT for dense frame-to-frame optical flow."""

    def __init__(self, device: str = "cuda"):
        self.device = device
        # from torchvision.models.optical_flow import raft_large, Raft_Large_Weights
        # weights = Raft_Large_Weights.DEFAULT
        # self.model = raft_large(weights=weights, progress=False).to(device).eval()
        # self.transforms = weights.transforms()
        raise NotImplementedError("Wire up torchvision RAFT here.")

    @torch.no_grad()
    def predict(self, frame_a: np.ndarray, frame_b: np.ndarray) -> np.ndarray:
        """Returns HxWx2 float32 flow field mapping frame_a pixels -> frame_b."""
        raise NotImplementedError


def align_depth_scale_shift(pred_depth: np.ndarray, ref_depth: np.ndarray, mask: np.ndarray | None = None):
    """
    Least-squares solve for (scale, shift) so that scale*pred_depth + shift ~= ref_depth,
    used to make relative monocular depth predictions roughly consistent across frames
    before they're used as a training prior. Standard trick from MiDaS / DPT literature.
    """
    if mask is not None:
        pred_depth = pred_depth[mask > 0]
        ref_depth = ref_depth[mask > 0]
    A = np.stack([pred_depth.ravel(), np.ones_like(pred_depth.ravel())], axis=1)
    b = ref_depth.ravel()
    solution, *_ = np.linalg.lstsq(A, b, rcond=None)
    scale, shift = solution
    return scale, shift
